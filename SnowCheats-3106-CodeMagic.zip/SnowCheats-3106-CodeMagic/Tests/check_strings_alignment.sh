#!/bin/bash
# The iOS app currently supports only pt-BR. Verify that its localized strings
# bundle exists and has keys, and that removed unsupported locales are not
# still referenced by the Xcode project.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STRINGS="$ROOT/ThreeOneOSSix/pt-BR.lproj/Localizable.strings"
PROJECT="$ROOT/ThreeOneOSSix.xcodeproj/project.pbxproj"

if [[ ! -f "$STRINGS" ]]; then
  echo "FAIL: pt-BR localization bundle is missing" >&2
  exit 1
fi
KEY_COUNT=$(grep -oE '^"[^"]+"' "$STRINGS" | tr -d '"' | sort -u | wc -l | tr -d ' ')
if [[ "$KEY_COUNT" -eq 0 ]]; then
  echo "FAIL: pt-BR localization bundle has no keys" >&2
  exit 1
fi
if grep -En 'en\.lproj|vi\.lproj|zh-Hans\.lproj' "$PROJECT"; then
  echo "FAIL: Xcode project still references an unsupported localization" >&2
  exit 1
fi

echo "pt-BR: $KEY_COUNT keys"
echo "PASS: supported localization present; unused locale references removed"

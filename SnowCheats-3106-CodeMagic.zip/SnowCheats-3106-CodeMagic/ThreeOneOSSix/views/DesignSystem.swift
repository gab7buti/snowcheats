import SwiftUI
import UIKit

enum StoreThemeColor: String, CaseIterable {
    case red, blue, purple, green, orange

    private static func mix(_ foreground: UIColor, _ background: UIColor, ratio: CGFloat) -> UIColor {
        var fr: CGFloat = 0, fg: CGFloat = 0, fb: CGFloat = 0, fa: CGFloat = 0
        var br: CGFloat = 0, bg: CGFloat = 0, bb: CGFloat = 0, ba: CGFloat = 0
        foreground.getRed(&fr, green: &fg, blue: &fb, alpha: &fa)
        background.getRed(&br, green: &bg, blue: &bb, alpha: &ba)
        return UIColor(red: fr * ratio + br * (1 - ratio), green: fg * ratio + bg * (1 - ratio), blue: fb * ratio + bb * (1 - ratio), alpha: fa * ratio + ba * (1 - ratio))
    }

    static var current: StoreThemeColor {
        StoreThemeColor(rawValue: UserDefaults.standard.string(forKey: "snowThemeColor") ?? "red") ?? .red
    }

    var accentUIColor: UIColor {
        switch self {
        case .red: return UIColor(red: 1.00, green: 0.035, blue: 0.13, alpha: 1)
        case .blue: return UIColor(red: 0.10, green: 0.48, blue: 1.00, alpha: 1)
        case .purple: return UIColor(red: 0.69, green: 0.30, blue: 1.00, alpha: 1)
        case .green: return UIColor(red: 0.04, green: 0.78, blue: 0.48, alpha: 1)
        case .orange: return UIColor(red: 1.00, green: 0.39, blue: 0.08, alpha: 1)
        }
    }

    var backgroundDark: UIColor {
        switch self {
        case .red: return UIColor(red: 0.035, green: 0.002, blue: 0.009, alpha: 1)
        case .blue: return UIColor(red: 0.004, green: 0.012, blue: 0.040, alpha: 1)
        case .purple: return UIColor(red: 0.022, green: 0.004, blue: 0.038, alpha: 1)
        case .green: return UIColor(red: 0.002, green: 0.025, blue: 0.016, alpha: 1)
        case .orange: return UIColor(red: 0.038, green: 0.010, blue: 0.002, alpha: 1)
        }
    }

    var surfaceDark: UIColor { Self.mix(accentUIColor, backgroundDark, ratio: 0.18) }
    var raisedDark: UIColor { Self.mix(accentUIColor, backgroundDark, ratio: 0.28) }
    var lineDark: UIColor { accentUIColor.withAlphaComponent(0.48) }

    var backgroundLight: UIColor { Self.mix(accentUIColor, .white, ratio: 0.035) }
    var surfaceLight: UIColor { Self.mix(accentUIColor, .white, ratio: 0.09) }
    var raisedLight: UIColor { Self.mix(accentUIColor, .white, ratio: 0.16) }
}

enum AppTheme {
    static var accent: Color { Color(uiColor: StoreThemeColor.current.accentUIColor) }
    static var pageBackground: Color { Color(uiColor: StoreThemeColor.current.backgroundDark) }
    static var consoleBackground: Color { Color(uiColor: StoreThemeColor.current.surfaceDark) }
    static let pageInset: CGFloat = 16
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
    static let contentCardCornerRadius: CGFloat = 20
    static let contentCardInset: CGFloat = 16
    static let contentCardPadding: CGFloat = 16
}

struct AppCardBorder: View {
    var body: some View {
        RoundedRectangle(
            cornerRadius: AppTheme.contentCardCornerRadius,
            style: .continuous
        )
        .strokeBorder(
            Color(uiColor: .separator).opacity(0.22),
            lineWidth: 0.5
        )
        .accessibilityHidden(true)
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(uiColor: .secondarySystemFill),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let icon = UIImage(named: "AppIcon60x60")
                ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
                ?? UIImage(named: "AppIcon") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "slider.horizontal.3")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.accent)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .accessibilityHidden(true)
    }
}
